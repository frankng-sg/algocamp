package com.devskiller.logs;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import java.time.temporal.*;
import java.util.*;
import java.util.stream.*;
import java.text.SimpleDateFormat;  
import java.util.Date;  
import net.lingala.zip4j.core.ZipFile;

public class LogsAnalyzer {

	private final static String TEMP_DIR = System.getProperty("java.io.tmpdir");

	public Map<String, Integer> countEntriesInZipFile(String searchQuery, File zipFile, LocalDate startDate, Integer numberOfDays) throws IOException {
		HashMap<String, Integer> result = new HashMap<>();

		File targetDir = new File(TEMP_DIR, UUID.randomUUID().toString());
		unzip(zipFile, targetDir);

		// TODO: Implement
		final File folder = new File(targetDir.toString());
		for (final File fileEntry : folder.listFiles()) {
			String filename = fileEntry.getName();
			String strDate = filename.split("logs_")[1].split("-access")[0];
			LocalDate currentDate = LocalDate.parse(strDate);
			Period intervalPeriod = Period.between(startDate, currentDate);
			int days = intervalPeriod.getDays();
			if (days <= numberOfDays.intValue()) {
	
				Scanner scan = new Scanner(fileEntry);
				int count = 0;
				while(scan.hasNext()){
					String line = scan.nextLine().toLowerCase().toString();
					if(line.contains(searchQuery)){
						count++;
					}
				}				
				
				result.put(filename, count);
				
			}
		}	
		return result;
	}

	public static void unzip(File targetZipFilePath, File destinationFolderPath) {
		try {
			ZipFile zipFile = new ZipFile(targetZipFilePath);
			zipFile.extractAll(destinationFolderPath.toString());
		} catch (Exception e) {
			throw new IllegalStateException("Unable to unpack zip file");
		}
	}
}
