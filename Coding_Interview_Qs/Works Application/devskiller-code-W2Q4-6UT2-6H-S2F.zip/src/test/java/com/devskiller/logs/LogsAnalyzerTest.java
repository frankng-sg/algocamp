package com.devskiller.logs;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LogsAnalyzerTest {

	File zipPath;

    @Before
    public void setUp() throws Exception {
	    zipPath = Paths.get(Paths.class.getResource("/logs-27_02_2018-03_03_2018.zip").toURI()).toFile();
    }

	@Test
	public void shouldContainEntriesForCorrectDays() throws IOException {
		//given
		LogsAnalyzer logsAnalyzer = new LogsAnalyzer();

		//when
		Map<String, Integer> counts = logsAnalyzer.countEntriesInZipFile("Mozilla", zipPath, LocalDate.of(2018, 2, 27), 3);

		//then
		assertThat(counts.size()).isEqualTo(3);
		assertThat(counts.containsKey("logs_2018-03-01-access.log")).isTrue();
		assertThat(counts.containsKey("logs_2018-02-28-access.log")).isTrue();
		assertThat(counts.containsKey("logs_2018-02-27-access.log")).isTrue();
	}
    @Test
   	public void shouldReturnLineCountsForMozilla() throws IOException {
   		//given
   		LogsAnalyzer logsAnalyzer = new LogsAnalyzer();

   		//when
   		Map<String, Integer> counts = logsAnalyzer.countEntriesInZipFile("Mozilla", zipPath, LocalDate.of(2018, 2, 27), 3);

   		//then
   		assertThat(counts.size()).isEqualTo(3);
   		assertThat(counts.get("logs_2018-03-01-access.log")).as("for logs_2018-03-01-access.log").isEqualTo(23);
   		assertThat(counts.get("logs_2018-02-28-access.log")).as("for logs_2018-02-28-access.log").isEqualTo(18);
   		assertThat(counts.get("logs_2018-02-27-access.log")).as("for logs_2018-02-27-access.log").isEqualTo(40);
   	}

	@Test
	public void shouldReturnLineCountsForSafari() throws IOException {
		//given
		LogsAnalyzer logsAnalyzer = new LogsAnalyzer();

		//when
		Map<String, Integer> counts = logsAnalyzer.countEntriesInZipFile("Safari", zipPath, LocalDate.of(2018, 2, 27), 4);

		//then
		assertThat(counts.size()).isEqualTo(4);
		assertThat(counts.get("logs_2018-03-02-access.log")).as("for logs_2018-03-02-access.log").isEqualTo(6);
		assertThat(counts.get("logs_2018-03-01-access.log")).as("for logs_2018-03-01-access.log").isEqualTo(16);
		assertThat(counts.get("logs_2018-02-28-access.log")).as("for logs_2018-02-28-access.log").isEqualTo(14);
		assertThat(counts.get("logs_2018-02-27-access.log")).as("for logs_2018-02-27-access.log").isEqualTo(25);
	}


}
